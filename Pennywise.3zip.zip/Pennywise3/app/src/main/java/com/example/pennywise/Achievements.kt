package com.example.pennywise

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.button.MaterialButton
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText

class Achievements : AppCompatActivity() {
    private lateinit var minGoalEditText: TextInputEditText
    private lateinit var maxGoalEditText: TextInputEditText
    private lateinit var progressBar: LinearProgressIndicator
    private lateinit var progressBar2: LinearProgressIndicator
    private lateinit var saveGoalsButton: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_achievements)

        // Initialize views
        minGoalEditText = findViewById(R.id.minGoalEditText)
        maxGoalEditText = findViewById(R.id.maxGoalEditText)
        progressBar = findViewById(R.id.progressBar)
        progressBar2 = findViewById(R.id.progressBar2)
        saveGoalsButton = findViewById(R.id.saveGoalsButton)

        saveGoalsButton.setOnClickListener {
            saveGoals()
        }
    }

    private fun saveGoals() {
        val minGoal = minGoalEditText.text.toString().toDoubleOrNull()
        val maxGoal = maxGoalEditText.text.toString().toDoubleOrNull()

        when {
            minGoal == null -> {
                minGoalEditText.error = "Please enter a valid number"
                return
            }
            maxGoal == null -> {
                maxGoalEditText.error = "Please enter a valid number"
                return
            }
            minGoal >= maxGoal -> {
                maxGoalEditText.error = "Must be greater than minimum goal"
                return
            }
            else -> {
                // Update progress bars (example logic)
                progressBar.progress = 50 // Replace with actual calculation
                progressBar2.progress = 30 // Replace with actual calculation
                Toast.makeText(this, "Goals saved successfully", Toast.LENGTH_SHORT).show()
            }
        }
    }
}



