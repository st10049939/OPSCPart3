package com.example.pennywise

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Sign_up : AppCompatActivity() {

    private lateinit var editTextUserN: EditText
    private lateinit var editTextPassW: EditText
    private lateinit var editTextConfirm: EditText
    private lateinit var editTextEmail: EditText
    private lateinit var buttonSign: Button
    private lateinit var textError: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        // Initialize views
        editTextUserN = findViewById(R.id.editTextUserN)
        editTextPassW = findViewById(R.id.editTextPassw)
        editTextConfirm = findViewById(R.id.editTextConfirm)
        editTextEmail = findViewById(R.id.editTextEmail)
        buttonSign = findViewById(R.id.buttonSign)
        textError = findViewById(R.id.textError)

        buttonSign.setOnClickListener {
            signUpUser()
        }
    }

    private fun signUpUser() {
        val name = editTextUserN.text.toString().trim()
        val password = editTextPassW.text.toString().trim()
        val confirmPassword = editTextConfirm.text.toString().trim()
        val email = editTextEmail.text.toString().trim()

        // Reset error messages
        editTextUserN.error = null
        editTextPassW.error = null
        editTextConfirm.error = null
        editTextEmail.error = null
        textError.visibility = TextView.GONE

        // Validate inputs
        when {
            name.isEmpty() -> {
                editTextUserN.error = "Username cannot be empty"
                editTextUserN.requestFocus()
                return
            }
            name.length < 4 -> {
                editTextUserN.error = "Username must be at least 4 characters"
                editTextUserN.requestFocus()
                return
            }
            password.isEmpty() -> {
                editTextPassW.error = "Password cannot be empty"
                editTextPassW.requestFocus()
                return
            }
            password.length < 6 -> {
                editTextPassW.error = "Password must be at least 6 characters"
                editTextPassW.requestFocus()
                return
            }
            confirmPassword.isEmpty() -> {
                editTextConfirm.error = "Please confirm your password"
                editTextConfirm.requestFocus()
                return
            }
            password != confirmPassword -> {
                editTextConfirm.error = "Passwords do not match"
                editTextConfirm.requestFocus()
                return
            }
            email.isEmpty() -> {
                editTextEmail.error = "Email cannot be empty"
                editTextEmail.requestFocus()
                return
            }
            !isValidEmail(email) -> {
                editTextEmail.error = "Please enter a valid email address"
                editTextEmail.requestFocus()
                return
            }
        }

        // If all validations pass, proceed with sign up
        Toast.makeText(this, "Sign up successful!", Toast.LENGTH_SHORT).show()
        // Here you would typically send the data to your backend
        // For now, we'll just show a success message
    }

    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
}