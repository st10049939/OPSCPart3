package com.example.pennywise

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.*
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import java.util.*


class Dashboard : AppCompatActivity() {

    data class Badge(
        val name: String,
        val iconRes: Int,
        val description: String
    )

    private lateinit var budgetBarChart: BarChart
    private lateinit var categoryPieChart: PieChart
    private lateinit var badgesContainer: LinearLayout
    private lateinit var budgetStatusText: TextView
    private lateinit var minGoalEditText: TextInputEditText
    private lateinit var maxGoalEditText: TextInputEditText
    private lateinit var progressBarMin: LinearProgressIndicator
    private lateinit var progressBarMax: LinearProgressIndicator
    private lateinit var saveButton: MaterialButton
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val badges = listOf(
            Badge("Gold", R.drawable.budget_master, "For excellent saving!"),
            Badge("Silver", R.drawable.silver_star, "For good effort!"),
            // Add more badges as needed
        )


        val buttonCat = findViewById<Button>(R.id.buttonCat);
        val buttonExp = findViewById<Button>(R.id.buttonExp);
        val buttonAch = findViewById<Button>(R.id.buttonAch);
        budgetBarChart = findViewById(R.id.budgetBarChart)
        categoryPieChart = findViewById(R.id.categoryPieChart)
        badgesContainer = findViewById(R.id.badgesContainer)
        budgetStatusText = findViewById(R.id.budgetStatusText)


        budgetBarChart = findViewById(R.id.budgetBarChart)
        //categoryPieChart = findViewById(R.id.categoryPieChart)

        //budgetStatusText = findViewById(R.id.budgetStatusText)*/


        findViewById<MaterialCardView>(R.id.categoriesCard).setOnClickListener {
            startActivity(Intent(this, Categories::class.java))
        }
        findViewById<MaterialCardView>(R.id.expensesCard).setOnClickListener {
            startActivity(Intent(this, Expenses::class.java))
        }
        findViewById<MaterialCardView>(R.id.achievementsCard).setOnClickListener {
            startActivity(Intent(this, Achievements::class.java))
        }

        buttonCat?.setOnClickListener {
            val intent = Intent(this, Categories::class.java)
            startActivity(intent)
        }

        buttonExp?.setOnClickListener {
            val intent = Intent(this, Expenses::class.java)
            startActivity(intent)
        }

        buttonAch?.setOnClickListener {
            val intent = Intent(this, Achievements::class.java)
            startActivity(intent)
        }
    }}




      /**  setupBudgetChart()
        setupCategoryChart()
        setupBadges()
        setupGoalTracking()



}


    private fun setupBudgetChart() {
        // Sample data - replace with your actual data
        val entries = ArrayList<BarEntry>()
        entries.add(BarEntry(0f, floatArrayOf(1000f, 1500f, 2000f))) // min, current, max

        val dataSet = BarDataSet(entries, "Budget Progress").apply {
            colors = listOf(
                Color.parseColor("#4CAF50"),  // Green for min
                Color.parseColor("#2196F3"),  // Blue for current
                Color.parseColor("#F44336")   // Red for max
            )
            stackLabels = arrayOf("Min Goal", "Current", "Max Goal")
        }
        budgetBarChart.apply {
            data = BarData(dataSet).apply { barWidth = 0.3f }
            description.isEnabled = false
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                valueFormatter = IndexAxisValueFormatter(arrayOf("This Month"))
            }
            axisLeft.axisMinimum = 0f
            axisRight.isEnabled = false
            animateY(1000)
            invalidate()
        }
    }    private fun setupCategoryChart() {
        // Sample data - replace with your actual data
        val entries = listOf(
            PieEntry(500f, "Food"),
            PieEntry(300f, "Transport"),
            PieEntry(200f, "Entertainment")
        )

        val dataSet = PieDataSet(entries, "Spending by Category").apply {
            colors = ColorTemplate.MATERIAL_COLORS.toList()
            valueTextColor = Color.WHITE
        }

        categoryPieChart.apply {
            data = PieData(dataSet).apply {
                setValueFormatter(PercentFormatter(this@Dashboard.categoryPieChart))
            }
            description.isEnabled = false
            setUsePercentValues(true)
            animateY(1000)
            invalidate()
        }
    }
    private fun setupBadges() {
        val badges = listOf(
            Badge("Budget Master", R.drawable.budget_master, "Stayed within budget for 3 months"),
            Badge("Early Saver", R.drawable.silver_star, "Saved 20% of income")
        )

        badgesContainer.removeAllViews()
        badges.forEach { badge ->
            val badgeView = LayoutInflater.from(this).inflate(com.google.android.material.R.layout.abc_action_bar_up_container, badgesContainer, false)
            badgeView.findViewById<TextView>(R.id.badgesTitle).text = badge.name
            badgeView.findViewById<ImageView>(R.id.badgesCard).setImageResource(badge.iconRes)
            badgeView.setOnClickListener {
                Toast.makeText(this, badge.description, Toast.LENGTH_SHORT).show()
            }
            badgesContainer.addView(badgeView)
        }
    }

    private fun setupGoalTracking() {
        saveButton.setOnClickListener {
            try {
                val minGoal = minGoalEditText.text.toString().toFloat()
                val maxGoal = maxGoalEditText.text.toString().toFloat()

                // Update progress bars
                progressBarMin.max = maxGoal.toInt()
                progressBarMin.progress = (minGoal * 0.7f).toInt() // Sample progress
                progressBarMax.max = maxGoal.toInt()
                progressBarMax.progress = (maxGoal * 0.8f).toInt() // Sample progress

                Toast.makeText(this, "Goals saved!", Toast.LENGTH_SHORT).show()
            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
*/