package com.example.pennywise

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    // Using lateinit to avoid null checks (we know these will be initialized in onCreate)
    private lateinit var editTextUser: EditText
    private lateinit var editTextPassword: EditText
    private lateinit var buttonLogin: Button
    private lateinit var buttonCreate: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        // Initialize views
        editTextUser = findViewById(R.id.editTextUser)
        editTextPassword = findViewById(R.id.editTextPassword)
        buttonLogin = findViewById(R.id.buttonLogin)
        buttonCreate = findViewById(R.id.buttonCreate)

        // Set click listeners
        buttonLogin.setOnClickListener { handleLogin() }
        buttonCreate.setOnClickListener { navigateToSignUp() }


        // Optional: Auto-focus username field when activity starts
        editTextUser.requestFocus()
    }

    private fun handleLogin() {
        // Get and trim input values
        val username = editTextUser.text.toString().trim()
        val password = editTextPassword.text.toString().trim()

        // Reset previous errors
        editTextUser.error = null
        editTextPassword.error = null

        // Validate inputs
        when {
            username.isEmpty() -> {
                editTextUser.error = "Username cannot be empty"
                editTextUser.requestFocus()
                return
            }
            password.isEmpty() -> {
                editTextPassword.error = "Password cannot be empty"
                editTextPassword.requestFocus()
                return
            }
            password.length < 6 -> {  // Adding minimum password length requirement
                editTextPassword.error = "Password must be at least 6 characters"
                editTextPassword.requestFocus()
                return
            }
        }

        // If validation passes, proceed with login
        attemptLogin(username, password)
    }

    private fun attemptLogin(username: String, password: String) {
        // Here you would normally make an API call or database check
        // For now, we'll simulate a successful login

        // Show loading indicator
        val progressDialog = ProgressDialog(this).apply {
            setMessage("Logging in...")
            setCancelable(false)
            show()
        }

        // Simulate network delay
        Handler(Looper.getMainLooper()).postDelayed({
            progressDialog.dismiss()

            // In a real app, you would check credentials here
            navigateToDashboard(username)
        }, 1500)
    }

    private fun navigateToDashboard(username: String) {
        Intent(this, Dashboard::class.java).apply {
            putExtra("USERNAME", username)  // Pass username to dashboard
            startActivity(this)
            finish()  // Close login activity to prevent going back
        }
    }

    private fun navigateToSignUp() {
        startActivity(Intent(this, Sign_up::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    // Optional: Handle back button to exit app from login screen
    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
    }
}